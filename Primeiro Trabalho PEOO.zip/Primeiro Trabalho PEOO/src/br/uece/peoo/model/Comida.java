package br.uece.peoo.model;

import java.awt.*;

/**
 *
 */
public class Comida extends Entidade {

    /**
     * @param x
     * @param y
     */
    public Comida(int x, int y) {
        super(x, y, Color.RED);
    }
}
